package MyStorage;

public class MySqlRepository extends ConnectionService{
    EntityManger em;

    public void persist throws SQLException(Object object){
       em.createConnection();

       try{
           em.getTransaction().begin();
           em.save(object);
           em.getTransaction().commit();
       }
       catch(){
           em.getTransaction().rollBack();
        }
    }

}
