package MyStorage;

public class Driver {

    public static void main(String[] args) {
        MongoDb mongo = new MongoDb("uname", "pwd", "dialect","url");


        /*String uname;
        String password;
        String path;
        String dialect;
        String connectionUrl;*/
    }
}
