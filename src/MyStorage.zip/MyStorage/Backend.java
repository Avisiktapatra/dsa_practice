package MyStorage;

public abstract class Backend {

    String uname;
    String password;
    String path;
    String dialect;
    String connectionUrl;

    public Backend(){}

    public Backend(String uname, String password, String dialect, String url) {
        this.uname = uname;
        this.password = password;
        this.dialect = dialect;
        this.connectionUrl = url;
    }

    public Backend(String path) {
        this.path = path;
    }

    public String getUserName(){
      return this.uname;
  }
    public String getPassword(){
      return this.password;
    }
    public String getDbDialect(){
      return this.dialect;
    }
    public String getConnectionUrl(){
      return this.connectionUrl;
    }

    public String getPath()
    {
        return this.path;
    }
}
