package MyStorage;

import java.util.HashMap;

public class ConnectionService {
    EntityManager eM;

    HashMap<String,String> properties = new HashMap<>();
    public void createConnection(String url){
       //try catch
         eM = Persistence.createEmtityMangaer();
        EntityManagerFctory factory = Persistence.createEntityManagerFactory(url);
    }

    public HashMap<String, String> setProperties{

        properties.put("url","");
        properties.put("uname","");
        return properties;
    }

    public void closeConnection(){
        em.close();
    }



}
