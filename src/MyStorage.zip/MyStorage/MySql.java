package MyStorage;

public class MySql extends Backend {
}
