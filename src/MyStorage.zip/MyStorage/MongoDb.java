package MyStorage;

public class MongoDb extends Backend {


}
