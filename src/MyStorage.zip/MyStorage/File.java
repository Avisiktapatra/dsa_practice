package MyStorage;

import java.io.*;

public class File extends Backend {

    public boolean checkPath() throws IOException{
        String path = getPath();
        try {
            BufferedReader br = new BufferedReader(new FileReader(new File(" ")));
        }
        catch(Exception e){
            System.out.println("File npt found");
        }


    }
   file underlying datastructure :  map<lineNo,Queue>- file
}
